function test_suite=test_ohspec3()
  initTestSuite;
end
function test_ohspec3_()
      
     S = ohspec3([],1:9);
end

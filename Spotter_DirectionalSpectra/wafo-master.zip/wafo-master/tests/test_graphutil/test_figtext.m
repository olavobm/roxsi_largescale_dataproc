function test_suite=test_figtext()
  initTestSuite;
end
function test_figtext_()
    figure(1); 
   H =  figtext(0,0,'test','normalized',[],'left','top'); 
 
   close all
end

function test_suite=test_torsethaugen()
  initTestSuite;
end
function test_torsethaugen_()
  [S,Sw,Ss]=torsethaugen([],[6 8],1); 
 
 close all
end

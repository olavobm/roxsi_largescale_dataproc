function test_suite=test_disectmfile()
  initTestSuite;
end
function test_disectmfile_()
   if ismatlab(), 
    t = disectmfile('disectmfile') 
  end
end

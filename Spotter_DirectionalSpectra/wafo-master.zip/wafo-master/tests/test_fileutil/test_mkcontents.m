function test_suite=test_mkcontents()
  initTestSuite;
end
function test_mkcontents_()
  % mkcontents('Test Toolbox',1.1,2) 
  ver test
end

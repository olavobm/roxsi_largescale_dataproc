% Module EXEC in WAFO Toolbox    
% Version  02-06-2017
%
%
% This directory shall contain a subdirectory with executable files for 
% the computer type at hand (pc win32, pc win64, pc linux64, etc). 
%
% When downloading the toolbox from the Internet, this directory  
% the executable files that have been compiled and tested at the time. 
% The source files are located in the wafo/source folder and may 
% be compiled again by the user. 

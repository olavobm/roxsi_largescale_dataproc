function test_suite=test_ochihubble()
  initTestSuite;
end
function test_ochihubble_()
  S = ochihubble; 
 plotspec(S)
end

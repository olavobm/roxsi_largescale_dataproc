function test_suite=test_mhelp2file()
  initTestSuite;
end
function test_mhelp2file_()
  mhelp2file(waforoot)
end

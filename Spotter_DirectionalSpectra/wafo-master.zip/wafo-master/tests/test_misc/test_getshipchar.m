function test_suite=test_getshipchar()
  initTestSuite;
end
function test_getshipchar_()
   ss = getshipchar(10,'servicespeed');
end

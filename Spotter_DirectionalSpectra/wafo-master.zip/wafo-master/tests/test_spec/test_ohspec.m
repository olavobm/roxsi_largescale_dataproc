function test_suite=test_ohspec()
  initTestSuite;
end
function test_ohspec_()
   S = ohspec(0.95);
end

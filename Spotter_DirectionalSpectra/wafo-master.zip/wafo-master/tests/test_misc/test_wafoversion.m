function test_suite=test_wafoversion()
  initTestSuite;
end
function test_wafoversion_()
       wafoversion onedim      % returns the version of the ONEDIM directory 
      wafoversion             % return current WAFO  version
end

function test_suite=test_roadspec()
  initTestSuite;
end
function test_roadspec_()
   S = roadspec(); 
  plotspec(S); 
 
  close all;
end
